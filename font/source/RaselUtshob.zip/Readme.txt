At first, thank you for downloading and using our free font.

You are expressly and emphatically restricted from all of the following:-

1. You can�t sell the fonts available on Lipighor
2. You can�t download them and upload on your website without our consent or proper legal permission.
3. You can't change the font information, sell or distribute them as your own creation or intellectual property.

If You've purchased the font from anyone, share his/her contact details with us, we will take legal step againt the fraud.

If you're interested in Creating your own font, please contact us- admin@lipighor.com